<template>
  <div class="platform-item">
    <img class="platform-banner" :src="bannerUrl" :style="'background-color:' + bgColor">
    <div class="content-box">
      <div class="platform-content">
        <div class="platform-title">{{ title }}</div>
        <div class="platform-text">{{ text }}</div>
        <div class="platform-btn" @click="goToPlatform">进入</div>
      </div>
      <div class="desc-img">
        <img :src="descUrl">
      </div>
      <div class="icons">
        <div class="item-line">
          <div class="item-icon">
            <div class="icon-container">
              <img :src="icon1.url">
              <div class="text-content">
                <div class="item-title">{{ icon1.title }}</div>
                <div class="item-info">{{ icon1.text }}</div>
              </div>
            </div>
          </div>
          <div class="item-icon">
            <div class="icon-container">
              <img :src="icon2.url">
              <div class="text-content">
                <div class="item-title">{{ icon2.title }}</div>
                <div class="item-info">{{ icon2.text }}</div>
              </div>
            </div>
          </div>
        </div>
        <div class="item-line">
          <div class="item-icon">
            <div class="icon-container">
              <img :src="icon3.url">
              <div class="text-content">
                <div class="item-title">{{ icon3.title }}</div>
                <div class="item-info">{{ icon3.text }}</div>
              </div>
            </div>
          </div>
          <div class="item-icon">
            <div class="icon-container">
              <img :src="icon4.url">
              <div class="text-content">
                <div class="item-title">{{ icon4.title }}</div>
                <div class="item-info">{{ icon4.text }}</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
  export default {
    name: 'platform-item',
    props: {
      platform: { type: String },
      title: { type: String },
      text: { type: String },
      bannerUrl: { type: String },
      descUrl: { type: String },
      bgColor: { type: String },
      icon1: { type: Object },
      icon2: { type: Object },
      icon3: { type: Object },
      icon4: { type: Object }
    },
    methods: {
      goToPlatform() {
        if (this.platform == 'coding') {
          window.open(this.codingUrl);
        } else {
          this.$router.push({ path: '/platform/' + this.platform });
          setTimeout(() => {
            document.documentElement.scrollTop = 0;
          });
        }
      }
    }
  };
</script>
<style lang="less">
  .platform-item {
    position: relative;
    .platform-banner {
      width: 100%;
      height: 520px;
    }
    .content-box {
      width: 1122px;
      margin: 0 auto;
      .platform-content {
        position: absolute;
        width: 1044px;
        left: 50%;
        top: 111px;
        transform: translateX(-50%);
        .platform-title {
          font-size: 40px;
          color: #ffffff;
          margin-bottom: 1rem;
          text-align: center;
        }
        .platform-text {
          color: #ffffff;
          opacity: 0.7;
          width: 100%;
          line-height: 2rem;
          margin-bottom: 2rem;
          font-size: 18px;
        }
        .platform-btn {
          color: #ffffff;
          border: 1px solid #ffffff;
          padding: 0.2rem 1rem;
          border-radius: 1rem;
          line-height: 1.5rem;
          z-index: 2;
          position: absolute;
          right: 0;
          &:hover {
            cursor: pointer;
          }
        }
      }
      .desc-img {
        width: 100%;
        transform: translateY(-180px);
        img {
          width: 100%;
        }
      }
      .icons {
        margin-top: -50px;
        .item-line {
          display: flex;
          .item-icon {
            flex: 1;
            margin-bottom: 5rem;
            display: flex;
            justify-content: center;
            .icon-container {
              display: flex;
              width: 20rem;
              img {
                margin-right: 1.2rem;
              }
              .text-content {
                .item-title {
                  font-size: 1.2rem;
                  color: #073D7D;
                }
                .item-info {
                  font-size: 0.8rem;
                  color: #6782A4;
                }
              }
            }
          }
        }
      }
    }
  }
</style>
