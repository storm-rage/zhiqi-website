<template>
  <div class="text-img-item">
    <template v-if="type == 1">
      <div class="text-img-item-text type1">
        <div class="text-title">
          <slot name="number"></slot>
          <span>{{ title }}</span>
        </div>
        <div class="text-content">{{ text }}</div>
      </div>
      <div class="text-img-item-img type1">
        <img :src="url">
      </div>
    </template>
    <template v-else-if="type == 2">
      <div class="text-img-item-img type2">
        <img :src="url">
      </div>
      <div class="text-img-item-text type2">
        <div class="text-title">
          <slot name="number"></slot>
          <span>{{ title }}</span>
        </div>
        <div class="text-content">{{ text }}</div>
      </div>
    </template>
  </div>
</template>
<script>
  export default {
    name: 'text-img-item',
    props: {
      type: { type: Number },
      title: { type: String },
      text: { type: String },
      url: { type: String }
    }
  };
</script>
<style lang="less">
  .text-img-item {
    display: flex;
    &-text {
      flex: 1;
      padding-top: 3rem;
      display: flex;
      flex-direction: column;
      margin-right: 2rem;
      .text-title {
        font-size: 2rem;
        margin-bottom: 1rem;
      }
      .text-content {
        color: #666666;
      }
    }
    &-text.type1 {
      margin-right: 2rem;
    }
    &-text.type2 {
      margin-left: 2rem;
    }
    &-img {
      display: flex;
      justify-content: flex-start;
      flex: 2;
    }
    &-img.type1 {
      justify-content: flex-start;
    }
    &-img.type2 {
      justify-content: flex-end;
    }
  }
</style>
