<template>
  <div class="login-container">
    <div class="login-main">
      <!--<img class="close" src="../images/close.svg" @click="closeSelf">-->
      <i class="close el-icon-close" @click="closeSelf"></i>
      <div class="login-logo">
        <img src="../images/logo-w.svg">
      </div>
      <div class="login-info">
        <div class="login-nav">
          <el-tabs v-model="activeName" @tab-click="changeTab">
            <el-tab-pane label="教师登录" name="teacher"></el-tab-pane>
            <el-tab-pane label="学生登录" name="student"></el-tab-pane>
          </el-tabs>
        </div>
        <el-form :model="store" :rules="rules" ref="loginForm">
          <!--教师登录-->
          <div v-if="activeName == 'teacher'" class="login-box">
            <el-form-item prop="Appid">
              <el-input placeholder="请输入学校代码" v-model="store.Appid" maxlength="6"></el-input>
            </el-form-item>

            <!--账号密码登录-->
            <div v-if="loginType == 'account'">
              <div class="box-item">
                <el-form-item prop="username">
                  <el-input placeholder="请输入工号或手机号" v-model="store.username"></el-input>
                </el-form-item>
              </div>
              <div class="box-item">
                <el-form-item prop="password">
                  <el-input placeholder="请输入密码" type="password" v-model="store.password"></el-input>
                </el-form-item>
              </div>
            </div>

            <!--手机验证登录-->
            <div v-if="loginType == 'mobile'">
              <div class="box-item">
                <el-form-item prop="phone">
                  <el-input placeholder="请输入手机号" v-model="store.phone"></el-input>
                </el-form-item>
              </div>
              <div class="box-item">
                <a v-if="countDown != 0" class="disabled-getcode">重新发送{{countDown}}</a>
                <a v-else-if="activeCode" class="getcode" @click="getCaptcha">获取验证码</a>
                <a v-else class="disabled-getcode">获取验证码</a>
                <el-form-item prop="code">
                  <el-input placeholder="请输入手机验证码" v-model="store.code"></el-input>
                </el-form-item>
              </div>
            </div>
          </div>

          <!--学生登录(账号密码)-->
          <div class="login-box" v-else>
            <el-form-item prop="Appid">
              <el-input placeholder="请输入学校代码" v-model="store.Appid" maxlength="6"></el-input>
            </el-form-item>
            <div class="box-item">
              <el-form-item prop="username">
                <el-input placeholder="请输入学号" v-model="store.username"></el-input>
              </el-form-item>
            </div>
            <div class="box-item">
              <el-form-item prop="password">
                <el-input placeholder="请输入密码" type="password" v-model="store.password"></el-input>
              </el-form-item>
              <a class="forget">
                <el-popover
                        placement="bottom"
                        trigger="hover"
                        :offset="0" content="请联系你的老师查看密码"
                        :visible-arrow="false">
                <span slot="reference">
                  忘记密码
                </span>
                </el-popover>
              </a>
            </div>
          </div>
          <el-button class="login-btn" type="primary" @click="onSubmit" :disabled="lockSubmitBtn" round>登 录</el-button>
        </el-form>
        <div class="divider-box">
          <div class="divider-line"></div>
          <div class="divider-text">其他登录方式</div>
          <div class="divider-line"></div>
        </div>
        <div class="login-type">
          <div class="login-type-campus" @click="campusLogin">
            <img src="../images/login-campus.svg">
            <span>智慧校园登录</span>
          </div>
          <div class="login-type-phone" @click="changeLoginType" v-if="activeName != 'student'">
            <img v-show="loginType == 'account'" src="../images/login-phone.svg">
            <img v-show="loginType == 'mobile'" src="../images/login-account.svg">
            <span>{{ loginType == 'account' ? '手机号登录' : '账号登录'}}</span>
          </div>
        </div>
      </div>
    </div>
    <div class="return" v-if="showReturn" @click="goToCoding">回到旧版</div>
    <iframe id="codingLogin" ref='codingLogin' :src="codingLoginHost + codingLoginPath" style="display: none"></iframe>
  </div>
</template>
<script>
  import '../style/login.less';
  import UuniV4 from 'uuid/v4';
  import ErrCodeMap from '../tools/errCodeMap';
  import { SRPClient } from '../tools/SRP.js';
  import { getQuery } from '../tools/tools';

  let phoneReg = /^1[23456789]\d{9}$/;
  let appIdReg = /^\d+$/;
  export default {
    data() {
      let validatePhone = (rule, value, callback) => {
        if (!value || !phoneReg.test(value)) callback(new Error('请输入正确的手机号'));
        else callback();
      };
      let validateAppid = (rule, value, callback) => {
        if (!value || !appIdReg.test(value)) callback(new Error('请输入正确的学校代码'));
        else callback();
      };
      return {
        store: {
          phone: '',
          code: '',
          username: '', // 账号
          password: '', // 密码
          Appid: '' // 学校Appid
        },
        errTime: 0, // 错误次数，超过3次弹出防水墙
        validateReg: /^1[34578]\d{9}$/,
        capAppid: '2095884785',
        rules: {
          Appid: [{ required: true, validator: validateAppid, trigger: 'change' }],
          phone: [{ required: true, validator: validatePhone, trigger: 'change' }],
          username: [{ required: true, validator: this.getUsernameTip, trigger: 'change' }],
          password: [{ required: true, message: '请输入密码', trigger: 'change' }],
          code: [{ required: true, message: '请输入手机验证码', trigger: 'change' }]
        },
        schoolItem: '', // 选择的学校信息
        activeCode: false, // 是否激活"获取验证码"按钮
        countDown: 0,
        LoginId: '',
        ClientId: '',
        loginType: 'account', // 默认账号密码登录
        activeName: 'teacher', // 切换
        lockSubmitBtn: false, // 锁定登录按钮
        showReturn: false, // 展示返回扣叮的按钮
        codingLoginPath: '/login_proxy/zq_proxy.html',
        token: '',
        getCodingMsg: false // 是否从coding得到消息
      };
    },
    watch: {
      'store.phone'(val) {
        this.activeCode = phoneReg.test(val) && appIdReg.test(this.store.Appid);
      },
      'store.Appid'(val) {
        this.activeCode = phoneReg.test(this.store.phone) && appIdReg.test(val);
      }
    },
    computed: {
      codingLoginHost() {
        if (location.hostname == 'test.learn.qq.com') return 'https://test.coding.qq.com';
        else if (location.hostname == 'learn.qq.com') return 'https://coding.qq.com';
        else return 'https://dev.coding.qq.com';
      }
    },
    mounted() {
      window.onkeypress = e => {
        // 监听回车事件登录
        if (e.key == 'Enter') this.onSubmit();
      };
      let from = getQuery('from');
      if (from == 'coding') this.showReturn = true;

      // 接受coding种cookie成功的message
      window.addEventListener('message', async event => {
        console.log('onmessage: ', event.data);
        if (event.data.success) {
          this.getCodingMsg = true;
          this.loginSuccessCb();
        }
        if (event.data.token) {
          if (this.$store.state.account.user) return;
          this.setCookie('Token', event.data.token); // 拿到code，设置到cookie里, 过期时间1天
          this.$store.dispatch('INIT_USER');
        }
        if (event.data.logout) {
          let token = this.getCookie('Token');
          await this.axiosPost({
            url: '/cgi/v1/account/LogoutToken',
            Token: token
          }).catch(err => err);
          this.setCookie('Token', '');
          this.$store.dispatch('CLEAR_USER');
          if (parent) {
            parent.postMessage({ logoutSuccess: true }, '*');
          }
        }
      });
    },
    methods: {
      changeTab(val) {
        this.activeName = val.name;
      },
      changeLoginType() {
        if (this.loginType == 'account') this.loginType = 'mobile';
        else this.loginType = 'account';
        setTimeout(() => {
          this.$refs.loginForm.clearValidate();
        }, 200);
      },
      async getCaptcha() {
        // 先检查手机号是否注册
        let isRegister = await this.axiosPost({
          url: '/cgi/v1/k12_platform/check_phone_registered',
          Appid: +this.store.Appid,
          RoleSpace: 'teacher',
          Phone: this.store.phone
        });
        if (!isRegister.IsRegistered) return this.$message.error('手机号未注册');

        // 获取验证码
        let randomToken = UuniV4();
        let schoolRes = await this.getSchoolByAppid();
        if (schoolRes.Code) return this.$message.error(schoolRes.Message);

        localStorage.setItem('school', JSON.stringify(schoolRes.School));
        this.LoginId =
          this.activeName == 'teacher' ? schoolRes.School.TeacherLoginId : schoolRes.School.StudentLoginId;
        this.ClientId =
          this.activeName == 'teacher' ? schoolRes.School.TeacherClientId : schoolRes.School.StudentClientId;
        this.setCookie('XSRF-TOKEN', randomToken); // 设置cookie，发请求带上
        let res = await this.axiosPost({
          url: '/cgi/v1/account/phone_login/submit_phone',
          cgiType: 'login', // 请求登录域名
          nation: 86,
          CompanyID: this.LoginId,
          phone: this.store.phone
        });
        if (res.code == 0) {
          this.$message.success('发送成功');
          this.countDown = 60;
          let id = setInterval(() => {
            if (this.countDown == 0) clearInterval(id);
            else this.countDown--;
          }, 1000);
        } else {
          this.$message.error(res.message || ErrCodeMap[res.code]);
        }
      },
      onSubmit() {
        if (!this.$refs.loginForm) return;
        this.$refs.loginForm.validate(async valid => {
          if (!valid) return false;
          this.lockSubmitBtn = true;
          if (this.loginType == 'account') {
            // 账号密码登录
            this.accountLogin();
          } else {
            if (this.errTime >= 3) {
              // 短信验证码登录
              this.checkCaptcha(() => this.phoneLogin());
            } else {
              this.phoneLogin();
            }
          }
        });
      },
      async accountLogin() {
        // 账号密码登录
        let randomToken = UuniV4();
        this.setCookie('XSRF-TOKEN', randomToken); // 设置cookie，发请求带上
        let schoolRes = await this.getSchoolByAppid();
        if (schoolRes.Code) {
          this.lockSubmitBtn = false;
          return this.$message.error(schoolRes.Message);
        }
        localStorage.setItem('school', JSON.stringify(schoolRes.School));

        this.LoginId =
          this.activeName == 'teacher' ? schoolRes.School.TeacherLoginId : schoolRes.School.StudentLoginId;
        this.ClientId =
          this.activeName == 'teacher' ? schoolRes.School.TeacherClientId : schoolRes.School.StudentClientId;
        let params = {
          url: '/cgi/v2/account/login/challenge',
          CompanyID: this.LoginId,
          cgiType: 'login',
          username: this.store.username,
          'X-XSRF-TOKEN': randomToken
        };
        if (this.activeName == 'teacher' && phoneReg.test(this.store.username)) {
          // 判断是手机号
          params.phone = this.store.username;
          params.nation = '86';
          delete params.username;
        }
        let res = await this.axiosPost(params);
        if (!res.data) {
          this.lockSubmitBtn = false;
          return this.$message.error(res.message || res.status);
        }

        if (this.errTime >= 3) {
          this.checkCaptcha(() => {
            this.getAM(res.data.group, res.data.salt, this.store.password, res.data.B);
          });
        } else {
          this.getAM(res.data.group, res.data.salt, this.store.password, res.data.B);
        }
      },
      async phoneLogin() {
        // 短信验证码登录
        let randomToken = UuniV4();
        let loginRes = await this.axiosPost({
          url: '/cgi/v1/account/phone_login/submit', // 调用手机登录接口
          cgiType: 'login', // 请求登录域名
          code: this.store.code,
          CompanyID: this.LoginId,
          'X-XSRF-TOKEN': randomToken
        });
        if (loginRes.code) {
          this.errTime++;
          this.$message.error(loginRes.message || ErrCodeMap[loginRes.code]);
          this.lockSubmitBtn = false;
          return;
        }

        let codeRes = await this.axiosGet({
          // 调用获取code接口
          url: '/cgi/oauth/authorize',
          cgiType: 'login', // 请求登录域名
          client_id: this.ClientId,
          scope: 'get_username',
          redirect_uri: location.protocol + '//' + location.host,
          response_type: 'code',
          appid: this.LoginId,
          'disable-sub-account-switch': 1,
          'disable-country': 1, // 教师端设置1
          state: parseInt(Math.random() * 10000, 10), // 随机数
          nonce: parseInt(Math.random() * 10000, 10) // 随机数
        });

        let code = codeRes.code;
        if (!code) {
          this.lockSubmitBtn = false;
          return this.$message.error('登录失败');
        }
        this.getToken(code);
      },
      async getAccountCode() {
        let codeRes = await this.axiosGet({
          // 调用获取code接口
          url: '/cgi/oauth/authorize',
          cgiType: 'login', // 请求登录域名
          client_id: this.ClientId,
          scope: 'get_username',
          redirect_uri: location.protocol + '//' + location.host,
          response_type: 'code',
          appid: String(this.LoginId),
          'disable-sub-account-switch': 1,
          'disable-country': 1,
          state: parseInt(Math.random() * 10000, 10), // 随机数
          nonce: parseInt(Math.random() * 10000, 10) // 随机数
        });
        let code = codeRes.code;
        this.getToken(code);
      },
      async getAM(group, salt, password, B) {
        let client = new SRPClient();
        await client.init(group, salt, password);
        let A = client.getPublicKey();
        client.setServerPublicKey(B);
        let M = client.getProof();

        let res = await this.axiosPost({
          url: '/cgi/v2/account/login/authenticate',
          CompanyID: this.LoginId,
          A: A,
          M: M,
          cgiType: 'login'
        });
        if (res.code === 0) {
          this.getAccountCode();
        } else {
          this.$message.error(res.message || ErrCodeMap[res.code]);
          this.lockSubmitBtn = false;
          this.errTime++;
        }
      },
      async getToken(code) {
        // 使用登录后的code换取token
        let tokenRes = await this.axiosPost({
          url: '/cgi/v1/account/GetToken',
          SdkAppID: '10001',
          AppID: this.store.Appid,
          RoleSpace: this.activeName,
          Code: code,
          ExtraFields: {
            RedirectURI: location.protocol + '//' + location.host
          }
        });
        if (tokenRes.Error) return this.$message.error(tokenRes.Message);
        if (tokenRes.Code) return this.$message.error(tokenRes.Message);
        // 登录成功拿到Token才继续
        if (tokenRes.Result) {
          let token = tokenRes.Result.Token;
          this.token = token;

          this.$refs.codingLogin.contentWindow.postMessage({
            token: token
          }, this.codingLoginHost);

          setTimeout(() => { // 1秒内，扣丁不返回结果，强制执行登录成功
            if (!this.getCodingMsg) this.loginSuccessCb();
          }, 1000);
        }
        this.lockSubmitBtn = false;
      },
      checkCaptcha(cb) {
        // 防水墙验证
        let captcha1 = new window.TencentCaptcha(this.capAppid, async res => {
          if (!res.randstr) return; // 用户取消

          let captchaRes = await this.axiosGet({
            url: '/service/captcha',
            ticket: res.ticket,
            randstr: res.randstr
          });
          if (captchaRes.response != 1) this.$message.error('防水墙验证不同通过');
          else cb();
        });
        captcha1.show(); // 显示验证码;
      },
      getSchoolByAppid() {
        return this.axiosPost({
          url: '/cgi/v1/k12_platform/describe_school',
          Appid: +this.store.Appid
        });
      },
      getUsernameTip(rule, value, callback) {
        if (!value) {
          if (this.activeName == 'teacher') callback(new Error('请输入工号或手机'));
          else callback(new Error('请输入学号'));
        } else {
          callback();
        }
      },
      goToCoding() {
        location.href = 'https://coding.qq.com/campus-system';
      },
      async loginSuccessCb() {
        this.setCookie('Token', this.token); // 拿到code，设置到cookie里, 过期时间1天
        this.$message({ type: 'success', message: '登录成功', duration: 1000 });
        await this.$store.dispatch('INIT_USER');
        this.axiosPost({ url: '/cgi/v1/k12_platform/report/report_login' }); // 登录上报

        let url = this.zhiqiUrl + '?token=' + this.token;
        this.$emit('success');
        location.href = url;
      },
      sendLogout() {
        this.$refs.codingLogin.contentWindow.postMessage({
          logout: true
        }, this.codingLoginHost);
      },
      closeSelf() {
        this.$emit('close');
      },
      campusLogin() { // 智慧校园登录
        let campusUrl = this.getCampusUrl();
        this.openTab(campusUrl);
      }
    }
  };
</script>
