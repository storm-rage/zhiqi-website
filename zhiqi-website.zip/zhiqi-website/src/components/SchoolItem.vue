<template>
  <div class="school-item" @mouseover="onHover">
    <el-card>
      <img :src="img">
      <div class="item-label">{{ label }}</div>
      <div class="text-content">
        <div class="item-title">{{ title}}</div>
        <div class="item-content">{{ text }}</div>
      </div>
    </el-card>
  </div>
</template>
<script>
  export default {
    name: 'school-item',
    props: {
      img: { type: String }, // 图片
      label: { type: String }, // 左上角标签
      title: { type: String }, // 标题
      text: { type: String } // 内容
    },
    methods: {
      onHover() {
        this.$emit('hover', this.label);
      }
    }
  };
</script>
<style lang="less">
  .school-item {
    &:nth-child(2) {
      margin: 0 1.5rem;
    }
    position: relative;
    background: #ffffff;
    flex: 1;
    width: 32%;
    .el-card {
      border: none;
      .el-card__body {
        padding: 0;
      }
    }
    .item-label {
      position: absolute;
      background: #3372FF;
      color: #ffffff;
      right: 1rem;
      top: 1rem;
      padding: 0 0.8rem;
      border-radius: 0.2rem;
    }
    .text-content {
      padding: 1rem 0 1.2rem 1.2rem;
      .item-title {
        color: #1F2126;
        margin-bottom: 0.5rem;
      }
      .item-content {
        color: #61656E;
        font-size: 0.8rem;
      }
    }
  }
</style>
