<template>
  <div class="contact">
    <div class="fuwuhao">
      <el-popover
        placement="left"
        width="160"
        trigger="hover"
        :offset="-45"
        :visible-arrow="false"
        v-model="visible">
        <img :src="baseUrl + fuwuhaoUrl" style="width: 100%; height: 100%">
        <div slot="reference">
          <img :src="baseUrl + url1">
        </div>
      </el-popover>
    </div>
    <div class="lianxi">
      <el-popover
        placement="left"
        width="200"
        trigger="hover"
        :offset="45"
        :visible-arrow="false"
        v-model="visible2">
        <div class="lianxi-dialog" style="text-align: center">
          <img :src="baseUrl + url3">
          <div class="tel">0755-86013388-810203</div>
          <div style="margin: 1rem 0; border-bottom: 1px solid #eeeeee"></div>
          <img :src="baseUrl + url4">
          <div class="email">AILearning_CSIG@tencent.com</div>
        </div>
        <div slot="reference">
          <img :src="baseUrl + url2">
        </div>
      </el-popover>
    </div>
  </div>
</template>
<script>
  export default {
    name: 'contact',
    data() {
      return {
        url1: 'concat/wechat.svg',
        url2: 'concat/phone.svg',
        url3: 'concat/phone2.svg',
        url4: 'concat/email.svg',
        fuwuhaoUrl: 'concat/fuwuhao.png',
        visible: false,
        visible2: false
      };
    }
  };
</script>
<style lang="less">
  .contact {
    position: fixed;
    right: 1rem;
    top: 50%;
    transform: translateY(-50%);
    background: #FFFFFF;
    width: 3rem;
    border-radius: 2rem;
    font-size: 12px;
    color: #2A365A;
    padding: 0.5rem;
    justify-content: center;
    box-shadow: 0 8px 23px 0 rgba(0,0,0,0.12);
    .fuwuhao, .lianxi {
      display: flex;
      justify-content: center;
      flex-direction: column;
      text-align: center;
      &:hover {
        cursor: pointer;
      }
      img {
        margin-bottom: 0.5rem;
      }
    }
    .fuwuhao {
      margin-top: 1rem;
      margin-bottom: 1rem;
    }
    .lianxi {
      margin-bottom: 1rem;
    }
  }
</style>
