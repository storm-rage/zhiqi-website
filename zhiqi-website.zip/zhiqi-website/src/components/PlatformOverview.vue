<template>
  <div class="platform-overview">
    <div class="platform-overview-img">
      <img :src="url">
    </div>
    <div class="platform-overview-line">
      <div class="platform-overview-line-item" v-for="item in list">
        <img :src="item.url" alt="">
        <div class="platform-overview-line-item-title">{{ item.title }}</div>
        <div class="platform-overview-line-item-text">{{ item.text }}</div>
      </div>
    </div>
  </div>
</template>
<script>
  export default {
    name: 'platform-overview',
    props: {
      url: { type: String },
      list: { type: Array }
    }
  };
</script>
<style lang="less">
  .platform-overview {
    &-img {
      text-align: center;
      margin-bottom: 4rem;
      img {
        width: 828px;
        height: 478px;
      }
    }
    &-line {
      display: flex;
      justify-content: center;
      &-item {
        width: 10rem;
        margin: 0 4rem;
        text-align: center;
        &-title {
          color: #073D7D;
          margin: 0.8rem 0;
        }
        &-text {
          display: table;
          text-align: initial;
          margin: 0 auto;
          color: #6782A4;
          font-size: 0.8rem;
        }
      }
    }
  }
</style>
