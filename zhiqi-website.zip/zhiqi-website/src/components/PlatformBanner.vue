<template>
  <div class="platform-banner">
    <img :src="url">
    <div class="platform-banner-title">{{ title }}</div>
    <div class="platform-banner-text">{{ text }}</div>
  </div>
</template>
<script>
  export default {
    name: 'platform-banner',
    props: {
      url: { type: String },
      title: { type: String },
      text: { type: String },
      color: { type: String }
    },
    mounted() {
      this.$el.querySelector('img').style['background'] = this.color;
    }
  };
</script>
<style lang="less">
  .platform-banner {
    position: relative;
    img {
      width: 100%;
      height: 280px;
    }
    &-title, &-text {
      position: absolute;
      left: 50%;
      color: #ffffff;
      transform: translateX(-50%);
    }
    &-title {
      top: 30%;
      font-size: 2.5rem;
    }
    &-text {
      bottom: 30%;
      display: table;
      margin: 0 auto;
    }
  }
</style>
