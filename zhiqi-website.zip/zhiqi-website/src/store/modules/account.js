import { getCookie, axiosPost } from '../../tools/tools';

export default {
	state: {
		user: ''
	},
	mutations: {
		SET_USER(state, val) {
			state.user = val;
		}
	},
	actions: {
		INIT_USER({ commit }) {
			let Token = getCookie('Token'); // 获取Token
			return new Promise((resolve, reject) => {
				axiosPost({
					url: '/cgi/v1/account/CheckToken',
					Token: Token
				}).then(user => {
          if (user.Code != 200) user = '';
					commit('SET_USER', user);
					resolve(user);
				});
			});
		},
    CLEAR_USER({ commit }) {
      commit('SET_USER', '');
    }
	}
};
