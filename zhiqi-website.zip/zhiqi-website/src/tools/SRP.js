/* eslint-disable */
"use strict";
let __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
let __generator = (this && this.__generator) || function (thisArg, body) {
    let _ = { label: 0, sent: function () { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function () { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
exports.__esModule = true;
let bcryptjs_1 = require("bcryptjs");
let jsbn_1 = require("jsbn");
let srp_1 = require("jsrp/lib/srp");
let jsrp_1 = require("jsrp");
let transform_1 = require("jsrp/lib/transform");
let browser_1 = require("create-hash/browser");
function PromiseWrap(func, that) {
    return function () {
        let args = [];
        for (let _i = 0; _i < arguments.length; _i++) {
            args[_i] = arguments[_i];
        }
        return new Promise(function (resolve) {
            args.length += 1;
            args[args.length - 1] = function () {
                resolve(arguments);
            };
            func.apply(that, args);
        });
    };
}
/**
 * 把10进制的字符串转化成N长度的16进制字符串
 * @param decimal 10进制字符串
 * @param n bit位数
 */
function padN(decimal, n) {
    let targetLength = n / 8 * 2;
    let hex = new jsbn_1.BigInteger(decimal).toString(16);
    if (hex.length < targetLength) {
        hex = new Array(targetLength - hex.length + 1).join('0') + hex;
    }
    return hex;
}
/**
 * 根据hash算法名 padN
 * @param decimal
 * @param hash
 */
function padNForHash(decimal, hash) {
    let m = {
        'sha512': 512,
        'sha256': 256,
        'sha1': 160
    };
    return padN(decimal, m[hash]);
}
// 修改x实现为bcrypt
srp_1.prototype.x = function (options) {
    let salt = options.salt.toString();
    let P = options.P.toString();
    let hash = bcryptjs_1.hashSync(P, salt);
    return new jsbn_1.BigInteger(bin2hex(hash), 16);
};
// 修改K实现为S而非hash(S)
srp_1.prototype.K = function (options) {
    return options.S;
};
//修改M实现为paddingHash以符合bc-java的协议
srp_1.prototype.M1 = function (options) {
    let A = transform_1.pad.toN(transform_1.buffer.toBigInteger(options.A), this.params);
    let B = transform_1.pad.toN(transform_1.buffer.toBigInteger(options.B), this.params);
    let K = transform_1.pad.toN(transform_1.buffer.toBigInteger(options.K), this.params);
    return browser_1(this.params.hash).update(A).update(B).update(K).digest();
};
srp_1.prototype.M2 = function (options) {
    let A = transform_1.pad.toN(transform_1.buffer.toBigInteger(options.A), this.params);
    let M = transform_1.pad.toN(transform_1.buffer.toBigInteger(options.M), this.params);
    let K = transform_1.pad.toN(transform_1.buffer.toBigInteger(options.K), this.params);
    return browser_1(this.params.hash).update(A).update(M).update(K).digest();
};
function bin2hex(s) {
    // From: http://phpjs.org/functions
    // +   original by: Kevin van Zonneveld (http://kevin.vanzonneveld.net)
    // +   bugfixed by: Onno Marsman
    // +   bugfixed by: Linuxworld
    // +   improved by: ntoniazzi (http://phpjs.org/functions/bin2hex:361#comment_177616)
    // *     example 1: bin2hex('Kev');
    // *     returns 1: '4b6576'
    // *     example 2: bin2hex(String.fromCharCode(0x00));
    // *     returns 2: '00'
    let i, l, o = "", n;
    s += "";
    for (i = 0, l = s.length; i < l; i++) {
        n = s.charCodeAt(i).toString(16);
        o += n.length < 2 ? "0" + n : n;
    }
    return o;
}
let SRPClient = /** @class */ (function () {
    function SRPClient() {
        this.client = new jsrp_1.client();
    }
    SRPClient.prototype.init = function (group, salt, password) {
        return __awaiter(this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, PromiseWrap(this.client.init, this.client)({ username: 'fakeusername', password: password, length: group })];
                    case 1:
                        _a.sent();
                        this.client.setSalt(bin2hex(salt));
                        return [2 /*return*/];
                }
            });
        });
    };
    SRPClient.prototype.getPublicKey = function () {
        return new jsbn_1.BigInteger(this.client.getPublicKey(), 16).toString();
    };
    SRPClient.prototype.generateVerifier = function () {
        let verifierBuffer = this.client.srp.v({
            P: this.client.PBuf,
            salt: this.client.saltBuf
        }).toString('hex');
        return new jsbn_1.BigInteger(verifierBuffer, 16).toString();
    };
    SRPClient.prototype.setServerPublicKey = function (B) {
        let hexB = padN(B, this.client.srp.params.length);
        this.client.setServerPublicKey(hexB);
    };
    SRPClient.prototype.getProof = function () {
        return new jsbn_1.BigInteger(this.client.getProof(), 16).toString();
    };
    SRPClient.prototype.checkServerProof = function (M2) {
        return this.client.checkServerProof(padNForHash(M2, this.client.srp.params.hash));
    };
    return SRPClient;
}());
exports.SRPClient = SRPClient;
let SRPServer = /** @class */ (function () {
    function SRPServer() {
        this.server = new jsrp_1.server();
    }
    SRPServer.prototype.init = function (group, salt, verifier) {
        return __awaiter(this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, PromiseWrap(this.server.init, this.server)({
                        length: group,
                        salt: bin2hex(salt),
                        verifier: transform_1.bigInt.toHex(new jsbn_1.BigInteger(verifier))
                    })];
                    case 1:
                        _a.sent();
                        return [2 /*return*/];
                }
            });
        });
    };
    SRPServer.prototype.setClientPublicKey = function (A) {
        let hexA = padN(A, this.server.srp.params.length);
        this.server.setClientPublicKey(hexA);
    };
    SRPServer.prototype.getPublicKey = function () {
        return new jsbn_1.BigInteger(this.server.getPublicKey(), 16).toString();
    };
    SRPServer.prototype.checkClientProof = function (M1) {
        return this.server.checkClientProof(padNForHash(M1, this.server.srp.params.hash));
    };
    SRPServer.prototype.getProof = function () {
        return new jsbn_1.BigInteger(this.server.getProof(), 16).toString();
    };
    return SRPServer;
}());
exports.SRPServer = SRPServer;
