import axios from 'axios';
// import Qs from 'qs';
import UuniV4 from 'uuid/v4';
import store from '../store';

export function getCookie(name) {
	let arr = document.cookie.match(new RegExp('(^| )' + name + '=([^;]*)(;|$)'));
	if (arr != null) {
		return unescape(arr[2]);
	}
	return null;
}

export function setCookie(name, value, expires, path, domain) {
	if (!expires) { // 默认1天有效期
		expires = 24 * 60 * 60;
	}
	let exp = new Date();
	exp.setTime(exp.getTime() + expires * 1000);
	let cookieName = name + '=' + escape(value) + ';expires=' + exp.toGMTString() + ';path=/';
	if (domain) {
		cookieName += ';domain=' + domain;
	}
	document.cookie = cookieName;
}

export function timeFormat(time, format) {
	if (!(time instanceof Date)) time = new Date(time);
	let o = {
		'M+': time.getMonth() + 1, // 月份
		'd+': time.getDate(), // 日
		'h+': time.getHours(), // 小时
		'm+': time.getMinutes(), // 分
		's+': time.getSeconds(), // 秒
		'q+': Math.floor((time.getMonth() + 3) / 3), // 季度
		'S': time.getMilliseconds() // 毫秒
	};
	if (/(y+)/.test(format)) {
		format = format.replace(RegExp.$1, (time.getFullYear() + '').substr(4 - RegExp.$1.length));
	}
	for (let k in o) {
		if (new RegExp('(' + k + ')').test(format)) {
			format = format.replace(RegExp.$1, (RegExp.$1.length === 1) ? (o[k]) : (('00' + o[k]).substr(('' + o[k]).length)));
		}
	}
	return format;
}

export function getQuery(name) {
	let reg = new RegExp('(^|&)' + name + '=([^&]*)(&|$)');
	let r = window.location.search.substr(1).match(reg);
	if (r != null) return unescape(r[2]);
	return null;
}

// 添加className
export function addClass(dom, className) {
	let newClassName = dom.className.split(' ');
	newClassName.push(className);
	dom.className = newClassName.join(' ');
}

// 移除className
export function removeClass(dom, className) {
	let newClassName = dom.className.split(' ').filter(name => {
		return name != className;
	});
	dom.className = newClassName.join(' ');
}

function axiosGetParam(param) {
	let url = param.url;
	let options = Object.assign({
		requestId: UuniV4()
	}, param);
	delete options.url;
	return {
		url: url,
		param: options
	};
}

export function axiosGet(param) {
	let options = axiosGetParam(param);
	return new Promise((resolve, reject) => {
		axios.get(options.url, {
			params: options.param
		}).then(res => {
			resolve(res.data);
		}).catch(err => {
			reject(err);
		});
	});
}

function axiosPostParam(param) {
	let url = param.url;
	let operateRole = localStorage.getItem('operateRole');
	let headers = {
		'Content-type': 'application/json'
	};
	if (param.CompanyID) {
		headers.CompanyID = param.CompanyID;
		delete param.CompanyID;
	}
	if (param['X-XSRF-TOKEN']) {
		headers['X-XSRF-TOKEN'] = param['X-XSRF-TOKEN'];
		delete param['X-XSRF-TOKEN'];
	}
	if (operateRole) {
		headers['operate_role'] = operateRole;
	}
	if (getCookie('Token')) headers['Token'] = getCookie('Token');
	delete param.url;
	let user = store.state.account.user;
	if (user) {
		param.tuser = {
			AppID: user.AppID,
			SdkAppID: user.SdkAppID,
			Uin: user.uin,
			UserName: user.Session.username
		};
	}
	return {
		url: url,
		param: param,
		headers: headers
	};
}

export function axiosPost(param) {
	let options = axiosPostParam(param);
	let headers = options.headers;
	delete options.headers;
	return new Promise((resolve, reject) => {
		axios.post(options.url, options.param, {
			headers: headers
		}).then(res => {
			let data = res.data;
			if (typeof data == 'string') {
				if (data.indexOf('UNAUTHENTICATED') > -1) expire(); // token过期或者被修改了
				else resolve({ Code: '-1', Message: data });
			} else if (data.code && String(data.code).indexOf('TIMEDOUT') > -1) {
				resolve({ code: '-2', Code: '2', Message: '接口超时', message: '接口超时' });
			} else if (data.Code == 401) { // 登录态过期，清除token
        resolve(data);
			} else {
				let action = /v[12]\/(.*?)\//.exec(options.url)[1];
				if (action == 'k12_platform') {
					if (data.Response && data.Response.Error) resolve(data.Response.Error);
					else resolve(data.Response);
				} else {
					resolve(data);
				}
			}
		}).catch(err => {
			let resp = err.response;
			let msg = resp.data.message || resp.statusText;
			resolve({ Code: resp.status, Message: msg });
		});
	});

  function expire() {
    setCookie('Token', '');
  }
}

export function getZhiQiUrl() {
  switch (location.hostname) {
    case '127.0.0.1':
      return 'http://127.0.0.1:8080';
    case 'dev.learn.qq.com':
      return 'https://teachdev.learn.qq.com';
    case 'test.learn.qq.com':
      return 'https://teachtest.learn.qq.com';
    case 'learn.qq.com':
      return 'https://teach.learn.qq.com';
  }
}

export function getCodingUrl() {
  switch (location.hostname) {
    case '127.0.0.1':
      return 'https://dev.coding.qq.com';
    case 'dev.learn.qq.com':
      return 'https://dev.coding.qq.com';
    case 'test.learn.qq.com':
      return 'https://test.coding.qq.com';
    case 'learn.qq.com':
      return 'https://coding.qq.com';
  }
}

// 打开新窗口，window.open会被浏览器拦截，需要使用a标签点击事件触发
export function openTab(url) {
  let link = document.createElement('a');
  link.href = url;
  link.target = '_blank';
  link.click();
}

export function getCampusUrl() {
	switch (location.hostname) {
		case '127.0.0.1':
			return 'https://sso.qq.com/statics/login-pc/?app=600035#/account';
		case 'dev.learn.qq.com':
		case 'teachdev.learn.qq.com':
			return 'https://sso.qq.com/statics/login-pc/?app=600035#/account';
		case 'test.learn.qq.com':
		case 'teachtest.learn.qq.com':
			return 'https://sso.qq.com/statics/login-pc/?app=600035#/account';
		case 'learn.qq.com':
		case 'teach.learn.qq.com':
			return 'https://sso.qq.com/statics/login-pc/?app=600024#/account';
	}
}

export function getCampusLogoutUrl() {
	switch (location.hostname) {
		case '127.0.0.1':
			return 'https://sso.qq.com/open/logout/600035';
		case 'dev.learn.qq.com':
		case 'teachdev.learn.qq.com':
			return 'https://sso.qq.com/open/logout/600035';
		case 'test.learn.qq.com':
		case 'teachtest.learn.qq.com':
			return 'https://sso.qq.com/open/logout/600035';
		case 'learn.qq.com':
		case 'teach.learn.qq.com':
			return 'https://sso.qq.com/open/logout/600024';
	}
}
