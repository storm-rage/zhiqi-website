<template>
  <div class="page-platform">
    <div class="part part1">
      <div class="part-title">腾讯青少年人工智能教育解决方案</div>
      <div class="part-text">{{ text }}</div>
      <img class="framework" src="https://tlearn-1259194201.cos.ap-guangzhou.myqcloud.com/zhiqi-website/framework.png">
    </div>
    <platform-item
      v-for="item in platformList"
      :key="item.key"
      :title="item.title"
      :bgColor="item.bgColor"
      :bannerUrl="item.bannerUrl"
      :descUrl="item.descUrl"
      :text="item.text"
      :icon1="item.icon1"
      :icon2="item.icon2"
      :icon3="item.icon3"
      :icon4="item.icon4"
      :platform="item.key"
    ></platform-item>
  </div>
</template>
<script>
  import PlatformItem from '../components/PlatformItem';

  export default {
    name: 'platform',
    components: { PlatformItem },
    data() {
      return {
        // https://tlearn-1259194201.cos.ap-guangzhou.myqcloud.com/zhiqi-website/platform/banner-1.svg
        text: '腾讯青少年人工智能教育解决方案是为K12学校提供的一款基于人工智能教育背景的产品。包含四个能力平台：腾讯扣叮是编程平台，' +
          '智启AI实验平台是一个人工智能实验教学平台，智启学堂打通了账号体系，是面向校园的教学管理平台；智启云控是基于物联的设备管控平台。',
        platformList: [
          {
            key: 'coding',
            title: '腾讯扣叮平台',
            bgColor: '#25A8BF',
            bannerUrl: this.baseUrl + '/platform/banner-1.png',
            descUrl: this.baseUrl + '/platform/desc-1.png',
            text: '腾讯自研的国产IDE工具平台。产品发挥腾讯自身技术优势，结合STEAM理念，赋能国内最专业的编程创客教育服务商，' +
              '为国内青少年人工智能教育贡献力量',
            icon1: { url: this.baseUrl + '/icon/icon1-1.svg', title: '前沿AI能力', text: '图像识别、人脸识别、声音识别、自然语言' },
            icon2: { url: this.baseUrl + '/icon/icon1-2.svg', title: '丰富硬件接入', text: '机器人、机甲、掌控板、无人机、机械臂' },
            icon3: { url: this.baseUrl + '/icon/icon1-3.svg', title: '全面素质培养', text: '艺术设计实验、游戏实验室' },
            icon4: { url: this.baseUrl + '/icon/icon1-4.svg', title: '海量创作素材', text: '腾讯IP角色素材、动漫场景素材、丰富曲库' }
          },
          {
            key: 'ai',
            title: '教学实验平台—智启AI实验',
            bgColor: '#5DCB6B',
            bannerUrl: this.baseUrl + '/platform/banner-2.png',
            descUrl: this.baseUrl + '/platform/desc-2.png',
            text: '结合腾讯人工智能实验室（智平/优图）前沿能力，紧扣国家课程标准而打造的高中人工智能实验学习平台。' +
              '通过“化繁为简”的任务式剖析，让学生对人工智能的实现原理产生直观认识和体验。',
            icon1: { url: this.baseUrl + '/icon/icon2-1.svg', title: '任务化教学', text: '实验任务目标、知识结构解析、任务步骤教学' },
            icon2: { url: this.baseUrl + '/icon/icon2-2.svg', title: '图形化展示', text: '流程图形化、调参图形化、结果图形化' },
            icon3: { url: this.baseUrl + '/icon/icon2-3.svg', title: '标准化案例', text: '国标教材配套案例、智能学情分析' },
            icon4: { url: this.baseUrl + '/icon/icon2-4.svg', title: '自动化报告', text: '自动化实验报告、专业标准输出' }
          },
          {
            key: 'teach',
            title: '教学管理平台 —— 智启学堂',
            bgColor: '#3372FF',
            bannerUrl: this.baseUrl + '/platform/banner-3.png',
            descUrl: this.baseUrl + '/platform/desc-3.png',
            text: '腾讯智启学堂：腾讯倾力打造的青少年人工智能教学管理平台，提供最专业的体系课程内容、' +
              '教学管理工具、自动化学情分析，降低老师教学门槛，简单方便的实施授课。',
            icon1: { url: this.baseUrl + '/icon/icon3-1.svg', title: '轻松“教”', text: '丰富课程资源、配套教学应用、课堂互动教学' },
            icon2: { url: this.baseUrl + '/icon/icon3-2.svg', title: '趣味“学”', text: '趣味课堂实验、创意作业任务、丰富课后内容' },
            icon3: { url: this.baseUrl + '/icon/icon3-3.svg', title: '智能“评”', text: '自动化评价、智能学情分析' },
            icon4: { url: this.baseUrl + '/icon/icon3-4.svg', title: '方便“管”', text: '课程管理、班级管理、学生管理' }
          },
          {
            key: 'iot',
            title: '智慧物联平台—智启云控',
            bgColor: '#7D8CEA',
            bannerUrl: this.baseUrl + '/platform/banner-4.png',
            descUrl: this.baseUrl + '/platform/desc-4.png',
            text: '智启云控物联平科技助力教育个台运用强大的物联网能力，将教学场景进行联动，' +
              '打造全新的智慧教室模式，性化、智慧化，迎接5G时代的到来。',
            icon1: { url: this.baseUrl + '/icon/icon4-1.svg', title: '编程+物联', text: '配套物联课程、智慧教室设备联动、AI能力赋能' },
            icon2: { url: this.baseUrl + '/icon/icon4-2.svg', title: '场景应用', text: '自定义情景模式、情景模式管理' },
            icon3: { url: this.baseUrl + '/icon/icon4-3.svg', title: '多设备联动', text: '搭建物联中控、多输入输出设备类型' },
            icon4: { url: this.baseUrl + '/icon/icon4-4.svg', title: '数据采集与存储', text: '接入数据、存储数据、处理数据、数据加密' }
          }
        ]
      };
    },
    methods: {}
  };
</script>
<style lang="less">
  .page-platform {
    .part1 {
      width: 1100px;
      padding: 5rem 0;
      text-align: center;
      margin: 0 auto;
      .part-title {
        font-size: 40px;
        margin-bottom: 2rem;
      }
      .part-text {
        color: #666666;
        text-align: left;
        line-height: 2rem;
        margin-bottom: 3rem;
      }
      .framework {
        width: 1100px;
        height: auto;
      }
    }
    .platform-item {
      margin-bottom: 4rem;
    }
  }
</style>
