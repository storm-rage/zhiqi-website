<template>
  <div class="page-course">
    <div class="banner">
      <img :src="baseUrl + 'course/banner.png'">
    </div>
    <div class="part part1">
      <div class="part-title">以人工智能课程体系为核心，延展开发<span style="font-weight: 300">STEAM</span>体系内容</div>
      <div class="part-image">
        <img :src="baseUrl + 'course/kecheng1.svg'">
      </div>
    </div>
    <div class="part part2">
      <div class="part-title"><span style="font-weight: 300">AI</span>课程体系学习进阶图</div>
      <div class="part-image">
        <img :src="baseUrl + 'course/kecheng2.svg'">
      </div>
    </div>
    <div class="part part3">
      <img class="part-banner" v-if="clientWidth <= 1920" :src="baseUrl + 'course/resource-banner.png'">
      <img class="part-banner" v-else :src="baseUrl + 'course/resource-banner2.png'">
      <div class="content">
        <div class="title">紧扣信息科技课标，与教育界共建课程资源</div>
        <div class="text">{{ text }}</div>
      </div>
      <div class="images">
        <school-item
          v-for="(item, index) in resourceList"
          :key="index"
          :img="baseUrl + item.img"
          :title="item.title">
        </school-item>
      </div>
    </div>
  </div>
</template>
<script>
  import SchoolItem from '../components/SchoolItem';

  export default {
    name: 'course',
    components: { SchoolItem },
    data() {
      return {
        text: '腾讯青少年人工智能教育，课程内容紧扣国家信息科技课程标准，依托腾讯前沿人工智能技术科学家，与教育部门相关学科专家、' +
          '高校人工智能领域教授、学校一线骨干教师、行业内头部合作伙伴共研课程体系与课程资源。',
        resourceList: [
          { img: 'course/resource1.png', title: '权威教育专家资源' },
          { img: 'course/resource2.png', title: '组建腾讯教育专家委员会' },
          { img: 'course/resource3.png', title: '与一线教师沟通交流' }
        ],
        clientWidth: document.body.clientWidth
      };
    },
    methods: {}
  };
</script>
<style lang="less">
  .page-course {
    .banner {
      text-align: center;
      background: #3372FF;
      img {
        width: 100%;
        max-width: 1920px;
        height: auto;
      }
    }
    .part {
      text-align: center;
      padding: 110px 0;
      &-title {
        font-size: 2rem;
        margin-bottom: 2rem;
      }
    }
    .part2 {
      background: #F7F9FC;
    }
    .part3 {
      padding: 0;
      position: relative;
      margin-bottom: 300px;
      .part-banner {
        width: 100%;
        height: 475px;
        object-fit: cover;
      }
      .content {
        width: 72rem;
        position: absolute;
        left: 50%;
        top: 0;
        transform: translateX(-50%);
        .title {
          font-size: 1.8rem;
          color: #ffffff;
          margin-top: 116px;
          margin-bottom: 67px;
          text-align: center;
        }
        .text {
          color: #ffffff;
          opacity: 0.7;
          width: 100%;
          line-height: 2rem;
          margin-bottom: 3rem;
          text-align: left;
        }
      }
      .images {
        position: absolute;
        bottom: -40%;
        width: 72rem;
        display: flex;
        justify-content: center;
        left: 50%;
        transform: translateX(-50%);
        img {
          width: 24rem;
          height: auto;
        }
      }
    }
  }
</style>
