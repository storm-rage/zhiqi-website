<template>
	<div class="page-home">
<!--    <iframe-->
<!--      style="width: 400px; height: 400px"-->
<!--      src="https://open.work.weixin.qq.com/wwopen/sso/3rd_qrConnect?appid=ww9d0437385160157a&redirect_uri=http%3A%2F%2Fdev.learn.qq.com&state=web_login&usertype=member&href=data:text/css;base64,LmltcG93ZXJCb3ggLnFyY29kZSB7d2lkdGg6IDI0MHB4OyBib3JkZXI6IG5vbmU7IG1hcmdpbjogMDt9Ci5pbXBvd2VyQm94IC50aXRsZSB7ZGlzcGxheTogbm9uZTt9Ci5pbXBvd2VyQm94IC5pbmZvIHtkaXNwbGF5OiBub25lO30KLnN0YXR1c19pY29uIHtkaXNwbGF5OiBub25lfQouaW1wb3dlckJveCAuc3RhdHVzIHt0ZXh0LWFsaWduOiBjZW50ZXI7fQ=="-->
<!--      frameborder="0">-->
<!--    </iframe>-->
		<div class="banner">
      <img v-if="clientWidth <= 1920" :src="baseUrl + 'home/banner.png'">
      <img v-else :src="baseUrl + 'home/banner2.png'">
    </div>
    <div class="part part1">
      <div class="part-title" style="margin-bottom: 5rem">腾讯青少年人工智能教育</div>
      <div class="part-content">
        <div class="text">{{ text1 }}</div>
        <div class="video-container">
          <video :src="baseUrl + videoUrl"></video>
          <img class="play" v-if="status == 0" :src="baseUrl + 'home/play.svg'" @click="play">
        </div>
      </div>
    </div>
    <div class="part part2">
      <div class="part-title">
        <span style="font-weight: 300">AI</span>教育解决方案
      </div>
      <div class="part-content">
        <div class="line-text">{{ text2 }}</div>
      </div>
      <div class="img-box">
        <img :src="baseUrl + 'home/ai.svg'">
      </div>
      <img class="left-img" :src="baseUrl + 'home/left.png'">
      <img class="right-img" :src="baseUrl + 'home/right.png'">
    </div>
    <div class="part part3">
      <div class="part-title">平台特色</div>
      <div class="line-text" style="margin-bottom: 3rem">{{ text3 }}</div>
      <div class="info-item">
        <div class="info-img">
          <img :src="baseUrl + 'home/info-ai.svg'">
        </div>
        <div class="info-msg">
          <div class="msg-title">强大的<span style="font-weight: 300">AI</span>技术支撑</div>
          <div class="msg-text">{{ text4 }}</div>
        </div>
      </div>
      <div class="info-item">
        <div class="info-msg">
          <div class="msg-title">全面的课程体系</div>
          <div class="msg-text">{{ text5 }}</div>
        </div>
        <div class="info-img">
          <img :src="baseUrl + 'home/info-course.png'">
        </div>
      </div>
      <div class="info-item">
        <div class="info-img">
          <img :src="baseUrl + 'home/info-example.png'">
        </div>
        <div class="info-msg">
          <div class="msg-title">经典的实验案例</div>
          <div class="msg-text">{{ text6 }}</div>
        </div>
      </div>
      <div class="info-item iot">
        <div class="info-msg">
          <div class="msg-title">智慧的编程物联</div>
          <div class="msg-text">{{ text7 }}</div>
        </div>
        <div class="info-img">
          <img :src="baseUrl + 'home/info-iot.svg'">
        </div>
      </div>
    </div>
    <div class="part part4">
      <div class="part-title" style="margin-bottom: 3rem">学校案例</div>
      <div class="part-content">
        <img class="banner" v-if="clientWidth <= 1920" :src="baseUrl + 'home/example-banner.png'" alt="">
        <img class="banner" v-else :src="baseUrl + 'home/example-banner2.png'" alt="">
        <div class="content">
          <div class="title">{{ curSchool.name }}</div>
          <div class="text">{{ curSchool.text }}</div>
        </div>
        <div class="images">
          <school-item
            @hover="hoverItem"
            v-for="(item, index) in schoolList"
            :key="index"
            :img="item.img"
            :label="item.label"
            :title="item.title"
            :text="item.text">
          </school-item>
        </div>
      </div>
    </div>
    <div class="part partner">
      <div class="part-title" style="margin-bottom: 5rem">我们的行业合作伙伴</div>
      <div class="partner-logo">
        <div class="logo-box" v-for="logo in logoList">
          <img :src="baseUrl + logo" alt="">
        </div>
      </div>
    </div>
    <div class="modal" v-if="showVideoModal"></div>
    <div class="modal-video" v-if="showVideoModal">
      <i class="close el-icon-circle-close" @click="closeVideoModal"></i>
      <video ref="myVideo" :src="baseUrl + videoUrl" controls></video>
    </div>
	</div>
</template>
<script>
  import '../style/pages/home.less';
  import SchoolItem from '../components/SchoolItem';
	export default {
    name: 'index',
    components: { SchoolItem },
    data() {
      return {
        status: 0, // 0未播放，1播放中
        text1: '腾讯青少年人工智能教育专注为学校提供全面的教学解决方案。依托于腾讯强大的人工智能、智慧物联、' +
          '大数据等技术基础，联合众多的领域专家、教育机构、一线名师，提供体系化的前沿课程（编程、创客、物联、人工智能）、' +
          '丰富的配套学习工具、以及教学实施服务。产品远景是降低学校教学门槛，助力青少年人工智能教育在国内的发展和普及。',
        text2: '腾讯倾力打造的青少年人工智能教学管理平台，提供最专业的体系课程内容、教学管理工具、自动化学情分析，' +
          '降低老师教学门槛，简单方便的实施授课。',
        text3: '腾讯倾力打造的青少年人工智能教学管理平台，提供最专业的体系课程内容、教学管理工具、自动化学情分析，' +
          '降低老师教学门槛，简单方便的实施授课。',
        text4: '前沿的AI技术：结合腾讯三大AI实验室AI Lab、优图实验室、微信AI的强大技术能力，将人脸识别、图像识别、' +
          '语音识别和自然语言处理等人工智能技术融合到青少年人工智能教育中，使编程与AI深入结合，产出行业领先的教学案例。',
        text5: '全面的课程体系：课程内容紧跟新课标，有行业优秀专家老师编写，腾讯人工智能科学家顾问团做专业咨询。' +
          '课程体系覆盖小学、初中和高中，课程种类覆盖图形化编程课程、基础语言编程课程、人工智能课程和创客硬件编程课程。' +
          '学科覆盖科学类、编程类、创科类、艺术类，充分满足学校教学需求。',
        text6: '实验案例紧跟配套课程，人工智能实验室里的六大经典实验紧跟教材，将复杂的AI算法图形化教学' +
          '，化繁为简、通俗易懂、浅显易学、激发兴趣。腾讯扣叮的八大实验室涵盖了硬件、创意、AI、艺术、小程序编程等模块，' +
          '从各个教学维度满足学生的创造力。',
        text7: '结合物联课程输出基于物联的教学案例，将硬件编程设备做联动，引入智慧教室的设备做基于编程的设备管控和模式情景管理。' +
          '由学校里专家老师和腾讯的物联专家输出经典案例和课程，结合腾讯的IOT HUB作为物联的底层支撑，在安全高效的基础上为AI教育赋能。',
        logoList: [
          'home/logo/1.png',
          'home/logo/2.png',
          'home/logo/3.png',
          'home/logo/4.png',
          'home/logo/5.png',
          'home/logo/6.png',
          'home/logo/7.png'
        ],
        schoolList: [
          { img: 'https://tlearn-1259194201.cos.ap-guangzhou.myqcloud.com/zhiqi-website/example-1.png',
            label: '深圳', title: '深圳市第二高级中学', text: '模范标杆 在国际国内大赛上屡获大奖' },
          { img: 'https://tlearn-1259194201.cos.ap-guangzhou.myqcloud.com/zhiqi-website/example-2.png',
            label: '上海', title: '上海卢湾一中小学', text: '上海市编程教育示范学校 苹果CEO库克访华学校' },
          { img: 'https://tlearn-1259194201.cos.ap-guangzhou.myqcloud.com/zhiqi-website/example-3.png',
            label: '云南', title: '云南沧源国门小学', text: '云南省现代教育示范学校 助力小学创客编程学习' }
        ],
        videoUrl: '%E8%85%BE%E8%AE%AF%E9%9D%92%E5%B0%91%E5%B9%B4%E4%BA%BA%E5%B7%A5%E6%99%BA%E8%83%BD%E6' +
          '%95%99%E8%82%B2-%E5%AE%A3%E4%BC%A0%E8%A7%86%E9%A2%91.mp4',
        showVideoModal: false,
        clientWidth: document.body.clientWidth,
        schoolMap: {
          '深圳': {
            name: '深圳市第二高级中学',
            text: '深圳第二高级中学是由深圳市重点投资和建设的一所现代化的大型寄宿制公办高中，是市教育局直属学校。' +
              '其学校开设的创客编程课程在整个深圳市乃至全国，都具有模范标杆的影响力！学科带头人周茂华老师更是国内知名创客教育专家，' +
              '带领二高的小创客们也在国际国内大赛上屡获大奖。'
          },
          '上海': {
            name: '上海卢湾一中小学',
            text: '上海卢湾一中小学是卢湾区区重点小学，上海市编程教育示范学校。曾经苹果CEO库克访华时，' +
              '曾亲临卢湾一中小学进行编程教育考察交流。学校也是少数将编程科纳入主课的学校，三年级以上学生经过选拔加入编程学习班，' +
              '课程内容也是具有艺术结合编程的特色课程。'
          },
          '云南': {
            name: '云南沧源国门小学',
            text: '云南沧源县国门小学虽然地处非常偏远的国境线，但在国家对云南地区教育的大力的扶持下，' +
              '其经过多年的蓬勃发展,以优质的教育资源和典雅的学习环境成为当地第一大学校，也是在2018年被评为“云南省现代教育示范学校”，' +
              '而腾讯人工智能教育也有幸跨越千里，打破教育资源的局限，助力国门小学创客编程学习。'
          }
        },
        curSchool: ''
      };
    },
    mounted() {
      this.curSchool = this.schoolMap['深圳'];
    },
		methods: {
      play() {
        this.status = 1;
        this.showVideoModal = true;
        setTimeout(() => {
          this.$refs.myVideo.play();
        });
      },
      closeVideoModal() {
        this.showVideoModal = false;
        this.status = 0;
      },
      hoverItem(label) {
        this.curSchool = this.schoolMap[label];
      }
		}
	};
</script>
