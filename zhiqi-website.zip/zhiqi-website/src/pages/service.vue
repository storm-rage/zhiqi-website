<template>
  <div class="page-service">
    <div class="banner">
      <img :src="baseUrl + 'service/banner.png'">
    </div>
    <div class="part part1">
      <div class="part-title">全面的师资培训</div>
      <div class="part-text">{{ text2 }}</div>
      <img :src="baseUrl + 'service/%E5%85%A8%E9%9D%A2%E7%9A%84%E5%B8%88%E8%B5%84%E5%9F%B9%E8%AE%AD.svg'">
    </div>
    <div class="part part2">
      <div class="part-title">专业的<span style="font-weight: 300">Saas</span>服务</div>
      <div class="items">
        <div class="service-item" v-for="item in serviceList">
          <img :src="baseUrl + item.url">
          <div class="">{{ item.text }}</div>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
  export default {
    name: 'service',
    data() {
      return {
        text1: '与合作伙伴共同提供专业的师资培训服务。选拔优秀培训教师为学校教师提供手把手的平台培训和技术咨询，让教师能够快速上手，' +
          '高效教学。Saas服务为学校提供可开账号即使用的服务，快速便捷高效的开通流程免去了私有化部署的复杂和冗长。',
        text2: '借助腾讯学院，外部合作伙伴力量共同进行师资培训。从编程能力，教学设计等方面全面提升教师的专业能力。',
        serviceList: [
          { url: 'service/service1.png', text: '标准化解决方案' },
          { url: 'service/service2.png', text: '快速提供解决方案' },
          { url: 'service/service3.png', text: '灵活的定价模式' },
          { url: 'service/service4.png', text: '更好的支持服务' },
          { url: 'service/service5.png', text: '用户快速上手' }
        ]
      };
    },
    methods: {
    }
  };
</script>
<style lang="less">
  .page-service {
    .banner {
      position: relative;
      text-align: center;
      background: #25A8BF;
      img {
        width: 100%;
        max-width: 1920px;
        height: auto;
      }
      &-title, &-text {
        position: absolute;
        left: 20%;
        color: #ffffff;
      }
      &-title {
        top: 30%;
        font-size: 2.5rem;
      }
      &-text {
        top: 46%;
        width: 35%;
      }
    }
    .part {
      padding: 7rem 0;
      width: 1100px;
      margin: 0 auto;
      .part-title {
        text-align: center;
        font-size: 2.2rem;
      }
    }
    .part1 {
      .part-title {
        margin-bottom: 1rem;
      }
      .part-text {
        text-align: center;
        color: #666666;
        margin-bottom: 3rem;
      }
      img {
        width: 100%;
        height: auto;
      }
    }
    .part2 {
      background: #F7F9FC;
      width: 100%;
      .part-title {
        margin-bottom: 4rem;
      }
      .items {
        display: flex;
        width: 60%;
        margin: 0 auto;
        .service-item {
          width: 15rem;
          text-align: center;
          color: #073D7D;
          margin-right: 4rem;
          img {
            width: 100%;
            margin-bottom: 1rem;
          }
        }
      }
    }
  }
</style>
