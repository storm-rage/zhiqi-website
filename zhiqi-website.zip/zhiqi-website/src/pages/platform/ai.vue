<template>
  <div class="platform-ai">
    <platform-banner
      :url="selfBaseUrl + 'banner.svg'"
      title="智启AI实验平台"
      :text="text1"
      color="#5DCB6B">
    </platform-banner>
    <div class="part part1">
      <platform-overview
        :url="selfBaseUrl + '智启ai实验平台.png'"
        :list="overviewItems">
      </platform-overview>
    </div>
    <div class="part part2">
      <div class="part-title">简洁高效的AI学习体验</div>
      <div class="part-text">{{ text2 }}</div>
      <text-img-item
        v-for="(item, index) in aiList"
        :key="index"
        :type="item.type"
        :title="item.title"
        :text="item.text"
        :url="item.url">
        <span slot="number" class="step-number">{{ index + 1 }}</span>
      </text-img-item>
    </div>
  </div>
</template>
<script>
  import PlatformBanner from '../../components/PlatformBanner';
  import PlatformOverview from '../../components/PlatformOverview';
  import TextImgItem from '../../components/TextImgItem';
  export default {
    components: { PlatformBanner, PlatformOverview, TextImgItem },
    name: 'platform-iot',
    data() {
      return {
        selfBaseUrl: this.baseUrl + '/platform-ai/',
        text1: '结合腾讯人工智能实验室（智平/优图）前沿能力，紧扣国家课程标准而打造的高中人工智能实验学习平台。' +
          '通过“化繁为简”的任务式剖析，让学生对人工智能的实现原理产生直观认识和体验。',
        overviewItems: [
          { url: this.baseUrl + '/platform-ai/任务化教学.svg', title: '任务化教学', text: '实验任务目标、知识结构解析、任务步骤教学' },
          { url: this.baseUrl + '/platform-ai/图形化展示.svg', title: '图形化展示', text: '流程图形化、调参图形化、结果图形化' },
          { url: this.baseUrl + '/platform-ai/标准化案例.svg', title: '标准化案例', text: '国标教材配套案例' },
          { url: this.baseUrl + '/platform-ai/自动化报告.svg', title: '自动化报告', text: '自动化实验报告、专业标准输出' }
        ],
        text2: '智启AI实验平台从模型的设计、训练、评估、应用的四大流程出发，以可视化的方式串联起AI实验的基本步骤。' +
          '并且通过报告的形式进行教学互动，提高学习效果。',
        aiList: [
          { type: 1, title: '模型设计', url: this.baseUrl + '/platform-ai/模型设计.svg',
            text: '在模型设计阶段，要依次确定数据集范围，划分训练集和验证集比例，调整实验参数，选择模型训练算法，调整算法相关参数。' },
          { type: 2, title: '模型训练', url: this.baseUrl + '/platform-ai/模型训练.svg',
            text: '模型训练过程中，平台会将算法运行过程中每个batch和epoch的训练过程和中间结果展示出来，用户可直观感受训练过程。' },
          { type: 1, title: '模型评估', url: this.baseUrl + '/platform-ai/模型评估.svg',
            text: '评估阶段针对模型的特点和训练结果进行评估，输出模型的评估结果，模型评估结果可作为该模型优劣的判断依据。' },
          { type: 2, title: '模型应用', url: this.baseUrl + '/platform-ai/模型应用.svg',
            text: '模型应用模块，用户可选择一个该实验的已训练模型，通过输入一些初始条件，来运行已训练好的模型，平台会输出模型的运算结果。' },
          { type: 1, title: '实验报告', url: this.baseUrl + '/platform-ai/实验报告.svg',
            text: '实验报告会展示该模型的整个训练过程中，参数的记录、模型的训练和评估结果。' +
              '同时报告中还设置了该实验的思考题，学生可提交报告给教师进行批改。' }
        ]
      };
    }
  };
</script>
<style lang="less">
  .platform-ai {
    .part {
      padding: 40px 0;
      margin: 0 auto;
      &-title {
        text-align: center;
        font-size: 2.5rem;
        margin-bottom: 2rem;
      }
      &-text {
        display: table;
        margin: 0 auto 2rem;
        width: 1044px;
        color: #666666;
      }
    }
    .part2 {
      background: #F7F9FC;
      .text-img-item {
        width: 1100px;
        margin: 0 auto 2rem;
        .step-number {
          color: #5DCB6B;
          font-size: 2.5rem;
          margin-right: 1rem;
        }
      }
    }
  }
</style>
