<template>
  <div class="platform-iot">
    <platform-banner
      :url="selfBaseUrl + 'banner.svg'"
      title="智启云控"
      :text="text1"
      color="#7D8CEA">
    </platform-banner>
    <div class="part part1">
      <platform-overview
        :url="selfBaseUrl + '智启云控.png'"
        :list="overviewItems">
      </platform-overview>
    </div>
    <div class="part part2">
      <div class="part-title">让编程更直观、有趣面向5G时代的学习平台</div>
      <div class="part-content">
        <img v-for="item in imgList" :src="item.url">
      </div>
    </div>
    <div class="part part3">
      <div class="part-title">设备高效管理</div>
      <div class="part-text">{{ text2 }}</div>
      <div class="part-content">
        <img :src="baseUrl + '/platform-iot/设备高效管理.svg'">
      </div>
    </div>
    <div class="part part4">
      <img class="banner" :src="baseUrl + '/platform-iot/智慧教室结合banner.svg'">
      <div class="part-title">智慧教室结合</div>
      <div class="part-content">
        <div class="classroom" v-for="(item, index) in classroomList" :key="index">
          <div class="classroom-img">
            <img :src="item.url">
          </div>
          <div class="classroom-content">
            <div class="classroom-title">{{ item.title }}</div>
            <div class="classroom-text">{{ item.text }}</div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
  import PlatformBanner from '../../components/PlatformBanner';
  import PlatformOverview from '../../components/PlatformOverview';
  import SchoolItem from '../../components/SchoolItem';
  export default {
    components: { PlatformBanner, PlatformOverview, SchoolItem },
    name: 'platform-iot',
    data() {
      return {
        selfBaseUrl: this.baseUrl + '/platform-iot/',
        text1: '智启云控物联平台，用科技助力教育，运用强大的物联网能力，将教学场景进行联动，' +
          '打造全新的智慧教室模式，个性化、智慧化，迎接5G时代的到来。',
        overviewItems: [
          { url: this.baseUrl + '/platform-iot/编程+物联.svg', title: '编程+物联', text: '配套物联课程、智慧教室设备联动、AI能力赋能' },
          { url: this.baseUrl + '/platform-iot/场景应用.svg', title: '场景应用', text: '自定义情景模式、情景模式管理' },
          { url: this.baseUrl + '/platform-iot/多设备联动.svg', title: '多设备联动', text: '搭建物联中控、多输入输出设备类型' },
          { url: this.baseUrl + '/platform-iot/数据采集与存储.svg', title: '数据采集与存储', text: '接入数据、存储数据、处理数据、数据加密' }
        ],
        imgList: [
          { url: this.baseUrl + '/platform-iot/无人机.png' },
          { url: this.baseUrl + '/platform-iot/机械臂.png' },
          { url: this.baseUrl + '/platform-iot/掌控板.png' },
          { url: this.baseUrl + '/platform-iot/机器人.png' }
        ],
        text2: '智启云控平台提供了对设备进行高效便捷的管理，包括设备的添加、查看、删除和控制，并且可以对多设备进行场景化定制和管理。',
        classroomList: [
          { url: this.baseUrl + '/platform-iot/智慧教室.png', title: '基于物联的智慧教室',
            text: '智慧教室是教学场景下，基于编程和物联的软硬件一体校园教学解决方案。为老师和学生提供智慧的教学环境，便捷的教室管理和智能的教学设施建设。' },
          { url: this.baseUrl + '/platform-iot/编程与智慧教室结合.png', title: '编程与智慧教室的结合',
            text: '将编程可与智慧教室相联动，通过编写代码能够控制教室里的设备，提升学生学习兴趣和成就感的同时，又能学以致用，积极实践。' },
          { url: this.baseUrl + '/platform-iot/物联与智慧教室的结合.png', title: '物联与智慧教室的结合',
            text: '结合物联技术，将教室内硬件环境进行有机整合，对教学设施设备形成统一管理，构建舒适教学环境，提升教学空间的使用效率。' }
        ]
      };
    }
  };
</script>
<style lang="less">
  .platform-iot {
    .part {
      padding: 40px 0;
      margin: 0 auto;
      &-title {
        text-align: center;
        font-size: 2.5rem;
        margin-bottom: 4rem;
      }
      &-text {
        color: #666666;
        display: table;
        margin: 0 auto 4rem;
      }
      .part-content {
        text-align: center;
      }
    }
    .part2 {
      background: #F7F9FC;
      .part-content {
        img {
          margin: 0 1rem;
        }
      }
    }
    .part4 {
      position: relative;
      padding: 0 !important;
      .banner {
        width: 100%;
        height: 457px;
        object-fit: cover;
      }
      .part-title {
        position: absolute;
        left: 50%;
        transform: translateX(-50%);
        top: 71px;
        color: #ffffff;
      }
      .part-content {
        display: flex;
        width: 100%;
        justify-content: center;
        transform: translateY(-260px);
        .classroom:nth-child(2) {
          margin: 0 29px;
        }
        .classroom {
          width: 360px;
          text-align: left;
          &-img {
            img {
              width: 100%;
            }
          }
          &-content {
            padding: 1rem;
            margin-top: -5px;
            background: #ffffff;
            box-shadow: 0 2px 12px 0 rgba(0,0,0,.1);
          }
          &-title {
            color: #1F2126;
            margin-bottom: 0.5rem;
          }
          &-text {
            font-size: 0.8rem;
            color: #61656E;
            line-height: 1.5rem;
          }
        }
      }
    }
  }
</style>
