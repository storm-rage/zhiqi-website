<template>
  <div class="platform-teach">
    <platform-banner
      :url="selfBaseUrl + 'banner.svg'"
      title="智启学堂"
      :text="text1"
      color="#3372FF">
    </platform-banner>
    <div class="part part1">
      <platform-overview
        :url="selfBaseUrl + '智启学堂.png'"
        :list="overviewItems">
      </platform-overview>
    </div>
    <div class="part part2">
      <div class="part-bar">
        <div :class="'part-bar-item ' + (active == 'teacher' ? 'active': '')" @click="switchType('teacher')">教师端</div>
        <div :class="'part-bar-item ' + (active == 'student' ? 'active': '')" @click="switchType('student')">学生端</div>
      </div>
      <div class="part-content">
        <template v-if="active == 'teacher'">
          <text-img-text
            v-for="(item, index) in teacherItems"
            :key="index"
            :type="item.type"
            :title="item.title"
            :text="item.text"
            :url="selfBaseUrl + item.url">
          </text-img-text>
        </template>
        <template v-else>
          <text-img-text
            v-for="(item, index) in studentItems"
            :key="index"
            :type="item.type"
            :title="item.title"
            :text="item.text"
            :url="selfBaseUrl + item.url">
          </text-img-text>
        </template>
      </div>
    </div>
  </div>
</template>
<script>
  import PlatformBanner from '../../components/PlatformBanner';
  import PlatformOverview from '../../components/PlatformOverview';
  import TextImgText from '../../components/TextImgItem';
  export default {
    name: 'platform-teach',
    components: { TextImgText, PlatformBanner, PlatformOverview },
    data() {
      return {
        active: 'teacher',
        text1: '腾讯倾力打造的青少年人工智能教学管理平台，提供最专业的体系课程内容、教学管理工具、自动化学情分析，' +
          '降低老师教学门槛，简单方便的实施授课。',
        selfBaseUrl: this.baseUrl + '/platform-teach/',
        overviewItems: [
          { url: this.baseUrl + '/platform-teach/教.svg', title: '轻松“教”', text: '丰富课程资源、配套教学应用、课堂互动教学' },
          { url: this.baseUrl + '/platform-teach/评.svg', title: '智能“评”', text: '自动化评价、智能学情分析' },
          { url: this.baseUrl + '/platform-teach/学.svg', title: '趣味“学”', text: '趣味课堂实验、创意作业任务、丰富课后内容' },
          { url: this.baseUrl + '/platform-teach/管.svg', title: '方便“管”', text: '课程管理、班级管理、学生管理' }
        ],
        teacherItems: [ // type: 1图片在右边，2图片在左边
          { type: 1, title: '丰富的课程资源中心', url: '丰富的课程资源中心.svg',
            text: '提供给教师课程库进行课程查看、本校作业库进行作业查看、本校课件库进行课件管理和编辑。' },
          { type: 2, title: '智能化学情分析', url: '智能化学情分析.svg',
            text: '针对平台的教学数据进行统计和分析。教师可查看自己教学数据和学生的个人学习数据。' },
          { type: 1, title: '互动的课堂教学', url: '互动教学课堂.svg',
            text: '教师在上课页面全屏展示课程内容，并可以实时查看学生作业完成情况，按课程进度发送课件信息给学生。' },
          { type: 2, title: '自动化作业管理', url: '自动化作业管理.svg',
            text: '教师可总览学生作业完成情况、也可通过每节课下的作业题查看每一题的学生完成情况。此外，平台还支持AI自动判分功能。' },
          { type: 1, title: '学习数据', url: '学习数据.svg',
            text: '智启学堂为学生提供了复习场景，学生可在学习完本节课程内容后，回顾课程和本节习题。' }
        ],
        studentItems: [
          { type: 1, title: '课前预习', url: '课前预习.svg',
            text: '智启学堂为学生提供了预习场景，学生可查看尚未学习过的课程内容，提前掌握知识点，为课堂学习做好铺垫。' },
          { type: 2, title: '上课学习', url: '上课学习.svg',
            text: '学生登进系统后，可直接进入某课程的上课模式，全屏显示课程内容，快捷链接到本节课的习题。' },
          { type: 1, title: '课后复习', url: '课后复习.svg',
            text: '智启学堂为学生提供了复习场景，学生可在学习完本节课程内容后，回顾课程和本节习题。' },
          { type: 2, title: '作业中心', url: '作业中心.svg',
            text: '作业中心为学生提供了作业的查看入口，可以去做作业，也可以总览自己的作业完成情况。' },
          { type: 1, title: '学习数据', url: '学习数据.svg',
            text: '智启学堂为学生提供了复习场景，学生可在学习完本节课程内容后，回顾课程和本节习题。' }
        ]
      };
    },
    methods: {
      switchType(active) {
        this.active = active;
      }
    }
  };
</script>
<style lang="less">
  .platform-teach {
    .part {
      padding: 40px 0;
      margin: 0 auto;
    }
    .part2 {
      background: #F7F9FC;
      .part-bar {
        display: flex;
        justify-content: center;
        .part-bar-item {
          font-size: 1.5rem;
          margin: 0 1.5rem 2rem 1.5rem;
          position: relative;
          padding: 0.5rem 1.5rem;
          border-radius: 2rem;
          border: 1px solid rgba(0, 0, 0, 0.5);
          &:hover {
            cursor: pointer;
          }
          &.active {
            opacity: 1;
            background: #3372FF;
            color: #FFFFFF;
            border: 1px solid #3372FF;
          }
        }
      }
      .text-img-item {
        width: 1200px;
        margin: 0 auto;
      }
    }
  }
</style>
