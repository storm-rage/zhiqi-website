<template>
  <div class="t-header">
    <div class="content">
      <div class="logo" @click="goHome">
        <img src="../images/logo.svg">
      </div>
      <div class="action">
        <div
          :class="'action-item switch ' + (activeTab == 'home' ? 'active' : '')"
          @click="switchPage('home')">首页</div>
        <div
          :class="'action-item switch ' + (activeTab == 'course' ? 'active' : '')"
          @click="switchPage('course')">课程</div>
        <div
          :class="'action-item switch ' + (activeTab == 'platform' ? 'active' : '')"
          @click="switchPage('platform')">
          <el-dropdown class="header-dropdown" @command="handleCommand">
            <span style="display: flex">
              <span style="margin-right: 4px">平台</span>
              <img src="../images/arrow.svg">
            </span>
            <el-dropdown-menu slot="dropdown">
              <el-dropdown-item command="coding">腾讯扣叮</el-dropdown-item>
              <el-dropdown-item command="ai">腾讯智启AI实验平台</el-dropdown-item>
              <el-dropdown-item command="teach">腾讯智启学堂</el-dropdown-item>
              <el-dropdown-item command="iot">腾讯智启云控</el-dropdown-item>
            </el-dropdown-menu>
          </el-dropdown>
        </div>
        <div
          :class="'action-item switch ' + (activeTab == 'serve' ? 'active' : '')"
          @click="switchPage('serve')">服务</div>
        <template v-if="user">
          <el-tooltip class="item" effect="light" placement="bottom" popper-class="user-tooltip">
            <div slot="content">
              <div class="logout" @click="logout">
                <span>退出</span>
              </div>
            </div>
            <img class="action-item user-img" src="../images/user.png">
          </el-tooltip>
        </template>
        <template v-else>
          <div class="action-item login" @click="login">登录</div>
          <div class="action-item login" @click="wxLogin">微信登录</div>
        </template>
        <div class="action-item zhiqi" @click="goToZhiqi">进入智启学堂</div>
      </div>
    </div>
    <login ref="login" v-show="showLogin" @close="closeLogin" @success="loginSuccess"></login>
    <div class="modal" v-if="showLogin"></div>
    <el-dialog
      class="login-dialog"
      :visible.sync="showWxLogin"
      width="400px"
      @close="showWxLogin = false"
      :modal-append-to-body="false">
      <div id="weixin-code"></div>
    </el-dialog>
  </div>
</template>
<script>
  import Login from '../components/Login';
  export default {
    name: 't-header',
    components: { Login },
    data() {
      return {
        activeTab: 'home',
        activePlatform: '',
        showLogin: false,
        showWxLogin: false
      };
    },
    computed: {
      user() {
        return this.$store.state.account.user;
      }
    },
    watch: {
      $route(val) {
        let path = val.path;
        if (path.indexOf('platform') > -1) this.activeTab = 'platform';
      }
    },
    mounted() {
      let path = this.$route.path.split('/');
      if (path.indexOf('platform') > -1) this.activeTab = 'platform';
      else this.activeTab = path[path.length - 1];
      if (path.length == 3) this.activePlatform = path[path.length - 1];

      if (this.$route.query.login) {
        this.showLogin = true;
      }
    },
    methods: {
      switchPage(key) {
        let path = this.$route.path.split('/');
        if (path.length == 2 && this.activeTab == key) return;
        this.activeTab = key;
        this.$router.push({
          path: '/' + key
        });
        this.activePlatform = '';
      },
      handleCommand(key) {
        if (key == 'coding') {
          window.open(this.codingUrl);
          return;
        }
        if (this.activePlatform == key) return;
        this.activePlatform = key;
        this.activeTab = '';
        this.$router.push({
          path: '/platform/' + key
        });
      },
      login() {
        this.showLogin = true;
      },
      async goToZhiqi() {
        let Token = this.getCookie('Token'); // 获取Token
        let res = await this.axiosPost({
          url: '/cgi/v1/account/CheckToken',
          Token: Token
        }).catch(err => err);
        if (res.Code != 200) {
          this.showLogin = true;
        } else {
          let token = this.getCookie('Token');
          window.open(this.zhiqiUrl + '?token=' + token);
        }
      },
      closeLogin() {
        this.showLogin = false;
      },
      loginSuccess() {
        this.closeLogin();
      },
      async logout() { // 退出登录
        let token = this.getCookie('Token');
        await this.axiosPost({
          url: '/cgi/v1/account/LogoutToken',
          Token: token
        }).catch(err => err);
        this.setCookie('Token', '');
        this.$refs.login.sendLogout();
        this.$message.success('退出成功');
        this.$store.dispatch('CLEAR_USER');

        let school = localStorage.getItem('school') || '{}';
        school = JSON.parse(school);
        if (school.SchoolType == 1) {
          location.href = this.getCampusLogoutUrl();
        }
      },
      goHome() {
        location.href = '/';
      },
      wxLogin() {
        this.showWxLogin = true;
        let url = location.protocol + '//' + location.host;
        setTimeout(() => {
          new window.WxLogin({
            id: 'weixin-code',
            appid: 'wxf23c243813477f03',
            scope: 'snsapi_login',
            redirect_uri: encodeURIComponent(url),
            state: new Date().getTime()
          });
        });
      }
    }
  };
</script>
<style lang="less">
  .t-header {
    width: 100%;
    height: 90px;
    position: fixed;
    z-index: 9;
    background-color: #ffffff;
    box-shadow: 0 2px 12px 0 rgba(0,0,0,.1);
    .content {
      margin: 0 auto;
      display: flex;
      width: 1300px;
      justify-content: space-between;
      height: 100%;
      align-items: center;
      font-size: 18px;
      .logo {
        &:hover {
          cursor: pointer;
        }
      }
      .action {
        display: flex;
        justify-content: flex-end;
        align-items: center;
        .action-item {
          margin-left: 2.5rem;
          &:hover {
            cursor: pointer;
          }
        }
        .user-img {
          width: 2.5rem;
          height: 2.5rem;
        }
        .switch {
          color: #2A365A;
          position: relative;
          &.active:after {
            content: '';
            position: absolute;
            bottom: -6px;
            left: 0;
            width: 100%;
            height: 2px;
            background: #66DD75;
          }
        }
        .login {
          border: 1px solid #2A365A;
          border-radius: 17px;
          height: 34px;
          line-height: 34px;
          padding: 0 15px;
        }
        .zhiqi {
          background: #3372FF;
          border-radius: 16.5px;
          color: #FFFFFF;
          height: 34px;
          line-height: 34px;
          padding: 0 24px;
          font-size: 16px;
          text-align: center;
          margin-left: 20px;
        }
        .el-dropdown {
          color: inherit;
          font-size: inherit;
        }
      }
    }
  }
  .user-tooltip {
    .logout {
      padding: 0 1rem;
      &:hover {
        cursor: pointer;
      }
    }
  }
</style>
