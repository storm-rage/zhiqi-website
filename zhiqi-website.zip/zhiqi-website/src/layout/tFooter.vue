<template>
  <div class="t-footer">
    <div class="content">
      <div class="line line1">联系我们</div>
      <div class="line line2">
        <span class="line2-item" v-for="item in line2Items">
          <span class="label">{{ item.label }}</span>
          <span class="text">{{ item.text }}</span>
        </span>
      </div>
      <div class="divider"></div>
      <div class="line line3">
        <img style="margin-right: 20px" :src="baseUrl + tencentUrl">
        <span class="line3-item" v-for="item in line3Items" @click="goTo(item)">
          {{ item.text }}
        </span>
      </div>
      <div class="line line4">
        <span>京公网安备11010802020287</span>
        <span class="split">|</span>
        <span>京ICP备11018762号</span>
      </div>
    </div>
  </div>
</template>
<script>
  export default {
    name: 't-footer',
    data() {
      return {
        line2Items: [
          { label: '客服', text: '0755-86013388-810203' },
          { label: 'Email', text: 'AILearning_CSIG@tencent.com' },
          { label: '办公时间', text: '周一至周五9am-6pm周日10am-1pm' },
          { label: '办公地方', text: '广东省深圳市南山区深南大道10000号腾讯大厦' }
        ],
        line3Items: [
          { text: '腾讯云', url: 'https://cloud.tencent.com' },
          { text: '腾讯智慧校园', url: 'https://campus.qq.com' },
          { text: '腾讯AI开放平台', url: 'https://ai.qq.com' },
          { text: '腾讯优图', url: 'https://open.youtu.qq.com' }
        ],
        tencentUrl: 'Tencent.svg'
      };
    },
    methods: {
      goTo(item) {
       window.open(item.url);
      }
    }
  };
</script>
<style lang="less">
  .t-footer {
    background: #2F3032;
    height: auto;
    .content {
      margin: 0 15%;
      color: #FFFFFF;
      .line {
      }
      .line1 {
        margin-top: 3rem;
        margin-bottom: 1rem;
      }
      .line2 {
        &-item {
          font-size: 0.75rem;
          margin-right: 1.5rem;
          .label {
            opacity: 0.5;
            margin-right: 1rem;
          }
        }
      }
      .line3 {
        .line3-item {
          font-size: 14px;
          margin-right: 1.5rem;
          color: #888;
          &:hover {
            cursor: pointer;
            color: #3372FF
          }
        }
      }
      .line4 {
        font-size: 0.75rem;
        margin: 1rem 0 2rem 0;
        .split {
          margin: 0 1rem;
        }
      }
      .divider {
        width: 100%;
        height: 1px;
        opacity: 0.12;
        background: #FFFFFF;
        margin: 2rem 0 1rem 0;
      }
    }
  }
</style>
