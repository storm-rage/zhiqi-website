const Home = require('../pages/home');
const Course = require('../pages/course');
const Platform = require('../pages/platform');
const Service = require('../pages/service');

// 平台子页面
const Teach = require('../pages/platform/teach');
const Iot = require('../pages/platform/iot');
const AI = require('../pages/platform/ai');

const routes = [
	{ path: '/', redirect: '/home' },
	{ path: '/home', components: Home },
	{ path: '/course', components: Course },
	{ path: '/platform', components: Platform },
	{ path: '/platform/teach', components: Teach },
	{ path: '/platform/iot', components: Iot },
	{ path: '/platform/ai', components: AI },
	{ path: '/serve', components: Service },
	{ path: '*', redirect: '/' }
];

export default routes;
