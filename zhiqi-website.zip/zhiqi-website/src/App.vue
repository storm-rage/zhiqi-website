<template>
  <div class="app">
    <t-header></t-header>
    <div class="top-content">
      <router-view></router-view>
    </div>
    <t-footer></t-footer>
    <contact></contact>
    <div class="return" v-if="showReturn" @click="goToCoding">回到旧版</div>
  </div>
</template>
<script>
  import tHeader from './layout/tHeader';
  import tFooter from './layout/tFooter';
  import Contact from './components/Contact';
  export default {
    name: 'app',
    components: { tHeader, tFooter, Contact },
    data() {
      return {
        showReturn: false
      };
    },
    mounted() {
      let Token = this.getCookie('Token');
      if (Token) {
        this.$store.dispatch('INIT_USER');
      }
      if (this.$route.query.from == 'coding') this.showReturn = true;

      // mac os下把字体变细
      if (navigator.userAgent.indexOf('Mac OS') > -1) {
        document.querySelector('body').style['font-weight'] = '400';
      }
      this.wxLogin();
    },
    methods: {
      async wxLogin() {
        let code = this.$route.query.code;
        if (code) {
          let res = await this.axiosPost({
            url: '/cgi/v1/k12_platform/account/wechat_login',
            CodeType: 2,
            Code: code,
            RoleSpace: 'teacher'
          }).catch(err => err);
          console.log(res);
        }
      },
      goToCoding() {
        location.href = 'https://coding.qq.com/campus-system/';
      }
    }
  };
</script>
<style lang="less">
  .app {
    height: 100%;
    display: flex;
    flex-direction: column;
    justify-content: space-between;
    .top-content {
      margin-top: 90px;
    }
    .return {
      position: fixed;
      background: #FFFFFF;
      right: 0;
      top: 7rem;
      border-radius: 20px 0 0 20px;
      color: #666666;
      height: 38px;
      text-align: center;
      width: 98px;
      line-height: 38px;
      &:hover {
        cursor: pointer;
      }
    }
  }
</style>
