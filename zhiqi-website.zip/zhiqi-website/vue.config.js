let config = {
	outputDir: 'zhiqi',
	devServer: {
		disableHostCheck: true,
		port: 8006,
		proxy: {
			'/cgi': {
				target: 'http://127.0.0.1:3000'
			}
		}
	},
  transpileDependencies: [
    'webpack-dev-server/client'
  ]
};

if (process.env.NODE_ENV == 'production') {
	config.publicPath = '/static/zhiqi';
}

module.exports = config;
